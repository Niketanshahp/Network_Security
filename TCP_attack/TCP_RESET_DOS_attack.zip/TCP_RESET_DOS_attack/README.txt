FOR TCP RESET ATTACK:

1. From client machine run "telnet SERVER_IP_ADDRESS"
2. From attacker machine run "tcp_reset_attack.c"


FOR TCP DoS ATTACK:

1. From attacker machine run "tcp_dos_attack.c"
2. From client machine run "telnet SERVER_IP_ADDRESS"

PLEASE CHANGE THE IP ADDRESS IN "tcp_reset_attack.c" AND "tcp_dos_attack.c" CODE AT RESPECTIVE FIELD ACCORDING TO THE SERVER.
