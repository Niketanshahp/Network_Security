1. Please add both the .c file into the directory "~/openssl_1.0.1/ssl/".
2. Then build the openssl_1.0.1 using
   a. sudo make
   b. sudo make test
   c. sudo make install
3. Copy the libcrypto.so.1.0.0 and libssl.so.1.0.0 into /lib/i386-linux-gnu and restart the apache server.
4. Above steps completes the patch for Heartbleed vulnerability.
