Compile the Client : gcc -Wall -o client  Client.c -L/usr/lib -lssl -lcrypto
Run :   ./client <host_name> <port_number> 


Compile the Server : gcc -Wall -o server Server.c -L/usr/lib -lssl -lcrypto
Run : sudo ./server <portnum> 



